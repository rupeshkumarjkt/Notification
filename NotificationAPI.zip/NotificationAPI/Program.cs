using Microsoft.Extensions.Configuration;
using Notification.Services.Generic;
using NotificationApi.Data;
using NotificationAPI.Configuration;
using NotificationAPI.Data;
using NotificationAPI.Data.Management;
using NotificationAPI.Repository;
using NotificationAPI.Service.Implementation;
using NotificationAPI.Service.Interface;
using NotificationAPI.ViewModels;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.

builder.Services.AddControllers();
// Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

//To DO: Move in seperate file
builder.Services.AddScoped(typeof(IRepository<>), typeof(Repository<>));
builder.Services.AddScoped<IDbContext, NotificationContext>();
builder.Services.AddScoped(typeof(IRepository<>), typeof(Repository<>));
builder.Services.AddTransient<IUnitOfWork, UnitOfWork>();
builder.Services.AddScoped(typeof(IGenericRepository<>), typeof(GenericRepository<>));
builder.Services.AddTransient(typeof(IGenericService<NotificationTypeViewModel>), typeof(NotificationTypeService<NotificationTypeViewModel>));
builder.Services.AddTransient(typeof(IGenericService<NotificationViewModel>), typeof(NotificationService<NotificationViewModel>));
builder.Services.AddTransient(typeof(INotificationService<NotificationViewModel>), typeof(NotificationService<NotificationViewModel>));

var app = builder.Build();

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseHttpsRedirection();

app.UseAuthorization();

app.MapControllers();

app.Run();
