﻿using NotificationAPI.ViewModels;

namespace NotificationAPI.Service.Interface
{
    public interface INotificationService<T>
    {
        Task<bool> SendNotification(ChannelViewModel channel);
        Task<bool> GetNotificationStatus(int id);
        Task<List<NotificationViewModel>> GetAllNotificationByDateRange(DateTime startDate, DateTime endDate);
        Task<List<NotificationViewModel>> GetAllNotificationByUser(int userId);
        Task<List<NotificationViewModel>> GetAllNotificationByType(int channelId);
    }
}
