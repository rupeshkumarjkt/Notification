﻿namespace NotificationAPI.Service.Interface
{
    public interface INotificationTypeService<T>
    {
    }
}
