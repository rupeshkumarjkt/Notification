﻿using AutoMapper;
using Notification.Services.Generic;
using NotificationAPI.Data.Entities;
using NotificationAPI.Data.Management;
using NotificationAPI.Repository;
using NotificationAPI.Service.Interface;
using NotificationAPI.ViewModels;

namespace NotificationAPI.Service.Implementation
{
    public class NotificationTypeService<T> : INotificationTypeService<NotificationTypeViewModel>, IGenericService<NotificationTypeViewModel>
    {
        private IGenericRepository<NotificationType> GenericRepository;
        private readonly IUnitOfWork unitOfWork;
        private readonly IMapper mapper;
        public NotificationTypeService(IUnitOfWork unitOfWork, IMapper mapper, IGenericRepository<NotificationType> genericRepository)
        {
            this.unitOfWork = unitOfWork;
            this.mapper = mapper;
            GenericRepository = genericRepository;
        }
        public NotificationTypeViewModel Create(NotificationTypeViewModel model)
        {
            var device = mapper.Map<NotificationTypeViewModel, NotificationType>(model);
            var entity = GenericRepository.Create(device);
            return mapper.Map<NotificationType, NotificationTypeViewModel>(entity);
        }

        public void Delete(int id)
        {
            var device = Task.Run(() => GenericRepository.GetById(id)).Result;
            GenericRepository.Delete(device);
        }

        public async Task<IEnumerable<NotificationTypeViewModel>> GetAll()
        {
            IList<NotificationTypeViewModel> models = new List<NotificationTypeViewModel>();
            var notificationTypes = await GenericRepository.GetAll();
            foreach (var notification in notificationTypes)
            {
                models.Add(mapper.Map<NotificationType, NotificationTypeViewModel>(notification));
            }
            return models.AsEnumerable();
        }

        public Task<IEnumerable<NotificationTypeViewModel>> GetAll(int page, int pageSize)
        {
            throw new NotImplementedException();
        }

        public Task<IEnumerable<NotificationTypeViewModel>> GetAll(string include)
        {
            throw new NotImplementedException();
        }

        public Task<IEnumerable<NotificationTypeViewModel>> GetAllWithData(int id)
        {
            throw new NotImplementedException();
        }

        public Task<IEnumerable<NotificationTypeViewModel>> GetByAny(int value)
        {
            throw new NotImplementedException();
        }

        public async Task<NotificationTypeViewModel> GetById(int id)
        {
            var device = await GenericRepository.GetById(id);
            var model = mapper.Map<NotificationType, NotificationTypeViewModel>(device);
            return model;
        }

        public void Update(int id, NotificationTypeViewModel model)
        {
            var device = mapper.Map<NotificationTypeViewModel, NotificationType>(model);
            GenericRepository.Update(id, device);
        }
    }
}
