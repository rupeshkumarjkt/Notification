﻿using AutoMapper;
using Notification.Services.Generic;
using NotificationAPI.Data.Entities;
using NotificationAPI.Data.Management;
using NotificationAPI.Repository;
using NotificationAPI.Service.Interface;
using NotificationAPI.ViewModels;

namespace NotificationAPI.Service.Implementation
{
    public class NotificationService<T> : INotificationService<NotificationViewModel>, IGenericService<NotificationViewModel>
    {
        private IGenericRepository<NotificationSent> GenericRepository;
        private readonly IUnitOfWork unitOfWork;
        private readonly IMapper mapper;
        public NotificationService(IUnitOfWork unitOfWork, IMapper mapper, IGenericRepository<NotificationSent> genericRepository)
        {
            this.unitOfWork = unitOfWork;
            this.mapper = mapper;
            GenericRepository = genericRepository;
        }
        public NotificationViewModel Create(NotificationViewModel model)
        {
            var device = mapper.Map<NotificationViewModel, NotificationSent>(model);
            var entity = GenericRepository.Create(device);
            return mapper.Map<NotificationSent, NotificationViewModel>(entity);
        }

        public void Delete(int id)
        {
            throw new NotImplementedException();
        }
        public async Task<bool> GetNotificationStatus(int id)
        {
            var device = await GenericRepository.GetById(id);
            var model = mapper.Map<NotificationSent, NotificationViewModel>(device);
            return model.status;
        }
        public async Task<IEnumerable<NotificationViewModel>> GetAll()
        {
            IList<NotificationViewModel> models = new List<NotificationViewModel>();
            var notificationsent = await GenericRepository.GetAll();
            foreach (var notification in notificationsent)
            {
                models.Add(mapper.Map<NotificationSent, NotificationViewModel>(notification));
            }
            return models.AsEnumerable();
        }

        public Task<IEnumerable<NotificationViewModel>> GetAll(int page, int pageSize)
        {
            throw new NotImplementedException();
        }

        public async Task<IEnumerable<NotificationViewModel>> GetAll(string include)
        {
            IList<NotificationViewModel> models = new List<NotificationViewModel>();
            var notifications = await GenericRepository.GetAll();
            foreach (var notification in notifications)
            {
                models.Add(mapper.Map<NotificationSent, NotificationViewModel>(notification));
            }
            return models.AsEnumerable();
        }

        public Task<IEnumerable<NotificationViewModel>> GetAllWithData(int id)
        {
            throw new NotImplementedException();
        }

        public Task<IEnumerable<NotificationViewModel>> GetByAny(int value)
        {
            throw new NotImplementedException();
        }

        public async Task<NotificationViewModel> GetById(int id)
        {
            var device = await GenericRepository.GetById(id);
            var model = mapper.Map<NotificationSent, NotificationViewModel>(device);
            return model;
        }

        public void Update(int id, NotificationViewModel model)
        {
            throw new NotImplementedException();
        }

        public async Task<bool> SendNotification(ChannelViewModel channel)
        {
            NotificationViewModel notification = new NotificationViewModel();
            switch (channel)
            {
                case ChannelViewModel.Email:
                    {

                        //ToDO: Get userID and email content, sent email code, and create notification model and save in DB
                        Create(notification);
                        return notification.status;

                    }
                case ChannelViewModel.SMS:
                    {
                        //ToDO: Get userID and SMS content,sent SMS code, and create notification model and save in DB
                        Create(notification);
                        return notification.status;
                    }
                case ChannelViewModel.PushNotification:
                    {
                        //ToDO: Get userID and PushNotification content,sent PushNotification code, and create notification model and save in DB
                        Create(notification);
                        return notification.status;                        
                    }
                default: return false;
            }            
        }

        public async Task<List<NotificationViewModel>> GetAllNotificationByDateRange(DateTime startDate, DateTime endDate)
        {
            List<NotificationViewModel> notificationViewModels = new List<NotificationViewModel>();
            var notifications= GenericRepository.FindBy(x=>x.SentDate>=startDate&&x.SentDate<=endDate).Result.ToList();
            if(notifications!=null && notifications.Count>0)
            {
                foreach (var item in notifications)
                {
                    NotificationViewModel notification = new NotificationViewModel();
                    notification= mapper.Map<NotificationSent, NotificationViewModel>(item);
                    notificationViewModels.Add(notification);
                }
            }
            return notificationViewModels;
        }

        public async Task<List<NotificationViewModel>> GetAllNotificationByUser(int userId)
        {
            List<NotificationViewModel> notificationViewModels = new List<NotificationViewModel>();
            var notifications = GenericRepository.FindBy(x => x.UserId== userId).Result.ToList();
            if (notifications != null && notifications.Count > 0)
            {
                foreach (var item in notifications)
                {
                    NotificationViewModel notification = new NotificationViewModel();
                    notification = mapper.Map<NotificationSent, NotificationViewModel>(item);
                    notificationViewModels.Add(notification);
                }
            }
            return notificationViewModels;
        }

        public async Task<List<NotificationViewModel>> GetAllNotificationByType(int channelId)
        {
            List<NotificationViewModel> notificationViewModels = new List<NotificationViewModel>();
            var notifications = GenericRepository.FindBy(x => x.Channel == channelId).Result.ToList();
            if (notifications != null && notifications.Count > 0)
            {
                foreach (var item in notifications)
                {
                    NotificationViewModel notification = new NotificationViewModel();
                    notification = mapper.Map<NotificationSent, NotificationViewModel>(item);
                    notificationViewModels.Add(notification);
                }
            }
            return notificationViewModels;
        }
    }
}
