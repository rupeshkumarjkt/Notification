﻿using AutoMapper.Internal;
using Microsoft.EntityFrameworkCore.Internal;
using Notification.Services.Generic;
using NotificationAPI.Data.Management;
using NotificationAPI.Repository;
using NotificationAPI.Service.Implementation;
using NotificationAPI.ViewModels;

namespace NotificationAPI.Configuration
{
    public static class IocContainerConfiguration
    {
        public static void ConfigureService(IServiceCollection services)
        {          
            services.AddScoped(typeof(IRepository<>), typeof(Repository<>));            
            services.AddTransient<IUnitOfWork, UnitOfWork>();
            services.AddScoped(typeof(IGenericRepository<>), typeof(GenericRepository<>));

            services.AddTransient(typeof(IGenericService<NotificationTypeViewModel>), typeof(NotificationTypeService<NotificationTypeViewModel>));
            services.AddTransient(typeof(IGenericService<NotificationViewModel>), typeof(NotificationService<NotificationViewModel>));
        }
    }
}
