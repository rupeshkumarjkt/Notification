﻿namespace NotificationAPI.ViewModels
{
    public enum ChannelViewModel
    {
        Email,
        SMS,
        PushNotification
    }
}
