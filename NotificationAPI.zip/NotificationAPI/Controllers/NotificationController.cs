﻿using EmailConfiguration.Controllers;
using Microsoft.AspNetCore.Mvc;
using Notification.Services.Generic;
using NotificationAPI.Service.Interface;
using NotificationAPI.ViewModels;

namespace NotificationAPI.Controllers
{
    public class NotificationController : BaseController<NotificationViewModel>
    {
        private readonly IGenericService<NotificationViewModel> Service;
        private readonly INotificationService<NotificationViewModel> notificationService;
        public NotificationController(IGenericService<NotificationViewModel> service) : base(service)
        {
            Service = service;
        }

        [HttpPost]
        public async Task<IActionResult> SendNotification(ChannelViewModel channel)
        {
            return new OkObjectResult(await notificationService.SendNotification(channel));
        }

        [HttpGet]
        public async Task<IActionResult> GetNotificationStatus(int notificationId)
        {
            return new OkObjectResult(await notificationService.GetNotificationStatus(notificationId));
        }

        [HttpGet]
        public async Task<IActionResult> GetAllNotificationByUser(int userID)
        {
            return new OkObjectResult(await notificationService.GetAllNotificationByUser(userID));
        }
        [HttpGet]
        public async Task<IActionResult> GetAllNotificationByDateRange(DateTime startDate, DateTime endDate)
        {
            return new OkObjectResult(await notificationService.GetAllNotificationByDateRange(startDate,endDate));
        }
        [HttpGet]
        public async Task<IActionResult> GetAllNotificationByType(int channelId)
        {
            return new OkObjectResult(await notificationService.GetAllNotificationByType(channelId));
        }
    }
}
