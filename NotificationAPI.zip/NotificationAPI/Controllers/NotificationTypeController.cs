﻿using EmailConfiguration.Controllers;
using Microsoft.AspNetCore.Mvc;
using Notification.Services.Generic;
using NotificationAPI.ViewModels;

namespace NotificationAPI.Controllers
{
    public class NotificationTypeController : BaseController<NotificationTypeViewModel>
    {
        private readonly IGenericService<NotificationTypeViewModel> Service;        
        public NotificationTypeController(IGenericService<NotificationTypeViewModel> service) : base(service)
        {
            Service = service;
        }
    }
}
