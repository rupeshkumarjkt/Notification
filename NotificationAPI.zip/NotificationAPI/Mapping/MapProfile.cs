﻿using AutoMapper;
using NotificationAPI.Data.Entities;
using NotificationAPI.ViewModels;


namespace NotificationAPI.Mappings
{
    
    public class MapsProfile : MapperConfigurationExpression
    {       
        public MapsProfile()
        {
            CreateMap<NotificationTypeViewModel, NotificationType>().ReverseMap();
            CreateMap<NotificationViewModel, NotificationSent>().ReverseMap();
        }
        
    }
}
