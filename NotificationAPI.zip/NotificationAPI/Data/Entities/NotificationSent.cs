﻿namespace NotificationAPI.Data.Entities
{
    public class NotificationSent
    {
        public int Id { get; set; }
        public int UserId { get; set; }
        public int NotificationTypeId { get; set; }
        public int Channel { get; set; }
        public string Content { get; set; }
        public DateTime SentDate { get; set; }
        public bool status { get; set; }
    }
}
