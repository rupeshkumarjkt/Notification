﻿using Microsoft.EntityFrameworkCore;
using NotificationApi.Data;
using NotificationAPI.Data.Entities;

namespace NotificationAPI.Data
{
    public class NotificationContext:DbContext,IDbContext
    {
        public DbSet<NotificationType> NotificationTypes { get; set; }
        public DbSet<NotificationSent> Notifications { get; set; }

        public NotificationContext(DbContextOptions options) : base(options)
        {
            LoadNotificationTypes();
            LoadNotification();
        }
        public void LoadNotificationTypes()
        {
            NotificationType typePromotional = new NotificationType();
            typePromotional.Id = 1;
            typePromotional.Name = "promotional";
            typePromotional.Description = "promotional";
            NotificationTypes.Add(typePromotional);
            NotificationType typeTransactional = new NotificationType();
            typeTransactional.Id = 2;
            typeTransactional.Name = "transactional";
            typeTransactional.Description = "transactional";
            NotificationTypes.Add(typeTransactional);
            NotificationType typeAlert = new NotificationType();
            typeAlert.Id = 3;
            typeAlert.Name = "alert";
            typeAlert.Description = "alert";
            NotificationTypes.Add(typeAlert);
        }
        public void LoadNotification()
        {
            
        }
    }
}
