﻿using NotificationApi.Data;
using System;
using System.Collections.Generic;

namespace NotificationAPI.Data.Management
{
    /// <summary>
    /// The Entity Framework implementation of IUnitOfWork
    /// </summary>
    public sealed class UnitOfWork : IUnitOfWork
    {
        private IDbContext dbContext;        
        private Dictionary<Type, object> repositories;
        
        public UnitOfWork(IDbContext _dbContext)
        {
            dbContext = _dbContext;
        }
        
        public IRepository<TEntity> GetRepository<TEntity>()
            where TEntity : class
        {
            if (repositories == null)
            {
                repositories = new Dictionary<Type, object>();
            }

            var type = typeof(TEntity);
            if (!repositories.ContainsKey(type))
            {
                repositories[type] = new Repository<TEntity>(dbContext);
            }

            return (IRepository<TEntity>)repositories[type];
        }       
        public int Commit()
        {
            // Save changes with the default options
            return dbContext.SaveChanges();
        }       
        public void Dispose()
        {
            Dispose(true);

            // ReSharper disable once GCSuppressFinalizeForTypeWithoutDestructor
            GC.SuppressFinalize(obj: this);
        }        
        private void Dispose(bool disposing)
        {
            if (disposing)
            {
                if (dbContext != null)
                {
                    dbContext.Dispose();
                    dbContext = null;
                }
            }
        }
    }
}
